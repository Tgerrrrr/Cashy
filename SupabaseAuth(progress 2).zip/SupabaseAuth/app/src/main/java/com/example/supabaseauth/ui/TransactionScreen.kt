package com.example.supabaseauth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.supabaseauth.model.Kas
import com.example.supabaseauth.viewmodel.CashState
import com.example.supabaseauth.viewmodel.CashViewModel
import com.example.supabaseauth.viewmodel.TransactionViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun TransactionScreen(
    cashViewModel: CashViewModel = viewModel(),
    transactionViewModel: TransactionViewModel = viewModel(),
    onAddTransaction: () -> Unit = {},
    onOpenHistory: () -> Unit = {}
) {

    val cashState = cashViewModel.cashState.collectAsStateWithLifecycle().value
    val totalSaldo = cashViewModel.totalSaldo.collectAsStateWithLifecycle().value

    val transactions by transactionViewModel.transactions.collectAsStateWithLifecycle()

    var selectedKas by remember { mutableStateOf<Kas?>(null) }
    var dropdownExpanded by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("All") }

    val kasList = when (cashState) {
        is CashState.Success -> cashState.cashList
        else -> emptyList()
    }

    fun formatRupiah(value: Double): String {
        return NumberFormat.getCurrencyInstance(Locale("in", "ID")).format(value)
    }

    LaunchedEffect(kasList) {
        if (selectedKas == null && kasList.isNotEmpty()) {
            selectedKas = kasList.first()
        }
    }

    LaunchedEffect(Unit) {
        transactionViewModel.loadAllTransactions()
    }

    val filteredTransactions = remember(transactions, filter) {
        transactions.filter {
            when (filter) {
                "Completed" -> it.status == "selesai"
                "Cancelled" -> it.status == "batal"
                "Failed"    -> it.status == "gagal"
                else        -> true
            }
        }
    }

    val currentSaldo = selectedKas?.saldo ?: totalSaldo

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CashyColors.Background)
    ) {

        Spacer(Modifier.height(20.dp))

        /* ================= SEARCH ================= */
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(50.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Color(0xFFF2F3F2))
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, contentDescription = null)
            Spacer(Modifier.width(10.dp))
            Text("Search Transaction", color = Color(0xFF7C7C7C))
        }

        Spacer(Modifier.height(16.dp))

        /* ================= CASH CARD ================= */
        Box(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .background(Color(0xFF002F3B), RoundedCornerShape(20.dp))
                .padding(19.dp)
        ) {

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    Text(
                        "Cash Balance",
                        color = Color.White,
                        fontSize = 13.sp
                    )

                    Box {
                        Row(
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(Color.White)
                                .clickable { dropdownExpanded = true }
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                selectedKas?.nama ?: "Select Kas",
                                fontSize = 12.sp
                            )
                            Spacer(Modifier.width(6.dp))
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            kasList.forEach {
                                DropdownMenuItem(
                                    text = { Text(it.nama) },
                                    onClick = {
                                        selectedKas = it
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Text(
                    text = formatRupiah(currentSaldo),
                    color = Color.White,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Bold
                )

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier
                            .height(40.dp)
                            .weight(1f)
                            .clip(RoundedCornerShape(30.dp))
                            .background(Color(0xFFF0F0F0))
                            .clickable { onAddTransaction() }
                            .padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Add Transaction", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(
            text = "Transaction History",
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.Black,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(12.dp))

        /* ================= FILTER ================= */
        Row(
            modifier = Modifier.padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("All", "Completed", "Cancelled", "Failed").forEach {
                FilterChip(
                    text = it,
                    selected = filter == it,
                    onClick = { filter = it }
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        /* ================= TRANSACTION LIST ================= */
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Text("No transactions found")
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredTransactions) { trx ->
                    TransactionItem(
                        name = trx.pelangganNama,
                        desc = "Order #${trx.id.take(8)} • ${trx.status}",
                        time = trx.waktu,
                        amount = trx.total,
                        status = trx.status
                    )
                }
            }
        }
    }
}

/* ================= ITEM ================= */

@Composable
private fun TransactionItem(
    name: String,
    desc: String,
    time: String,
    amount: Double,
    status: String
) {

    fun formatRupiah(value: Double): String {
        return NumberFormat.getCurrencyInstance(Locale("in", "ID")).format(value)
    }

    // Green for completed ("selesai"), red for cancelled ("batal") or failed ("gagal")
    val dotColor = when (status.lowercase()) {
        "selesai" -> Color(0xFF2A7F13)
        else      -> Color(0xFFD32F2F)
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        // Status dot
        Box(
            modifier = Modifier
                .size(12.dp)
                .clip(CircleShape)
                .background(dotColor)
        )

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.Bold)
            Text(desc, fontSize = 12.sp, color = Color.Gray)
            Text(time, fontSize = 10.sp, color = Color.Gray)
        }

        Text(
            text = formatRupiah(amount),
            fontSize = 12.sp
        )
    }
}

/* ================= FILTER CHIP ================= */

@Composable
private fun FilterChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(30.dp))
            .background(if (selected) Color(0xFF00657E) else Color(0xFFE6F3F6))
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            color = if (selected) Color.White else Color(0xFF00657E)
        )
    }
}