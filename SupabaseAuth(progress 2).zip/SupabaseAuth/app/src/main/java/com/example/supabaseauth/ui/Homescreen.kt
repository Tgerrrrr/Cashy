package com.example.supabaseauth.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.supabaseauth.viewmodel.AuthViewModel
import com.example.supabaseauth.viewmodel.CashState
import com.example.supabaseauth.viewmodel.CashViewModel
import com.example.supabaseauth.R

@Composable
fun HomeScreen(
    authViewModel: AuthViewModel,
    navController: NavController,
    onLogout: () -> Unit,
    cashViewModel: CashViewModel = viewModel()
) {
    val email by authViewModel.currentUserEmail.collectAsStateWithLifecycle()
    val role by authViewModel.currentUserRole.collectAsStateWithLifecycle()
    val cashState by cashViewModel.cashState.collectAsStateWithLifecycle()
    val totalSaldo by cashViewModel.totalSaldo.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CashyColors.Background)
            .verticalScroll(rememberScrollState())
    ) {
        //LOGO

        Box(
            modifier = Modifier
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.mipmap.ic_launcher_foreground),
                contentDescription = "Logo",
                modifier = Modifier
                    .size(100.dp)          // keep layout space small
                    .graphicsLayer {
                        scaleX = 1.5f      // visually bigger
                        scaleY = 1.5f
                    }
            )
        }

        // HEADER
        TransactionSummaryCard(
            cashState = cashState,
            totalSaldo = totalSaldo,
            onAddTransaction = {
                navController.navigate(Screen.Transaction.route)
            },
            onOpenHistory = {
                navController.navigate(Screen.History.route)
            }
        )

        // STATS
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            StatCard(
                modifier = Modifier.weight(1f),
                title = "Total Penjualan",
                value = "–",
                sub = "Lihat penjualan",
                icon = Icons.Default.PointOfSale,
                onClick = { navController.navigate(Screen.Sales.route) }
            )
        }

        Spacer(Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            StatCard(
                modifier = Modifier.weight(1f),
                title = "Produk",
                value = "–",
                sub = "Lihat produk",
                icon = Icons.Default.Inventory2,
                onClick = { navController.navigate(Screen.Product.route) }
            )

            StatCard(
                modifier = Modifier.weight(1f),
                title = "Pelanggan",
                value = "–",
                sub = "Lihat pelanggan",
                icon = Icons.Default.People,
                onClick = { navController.navigate(Screen.Customer.route) }
            )
        }

        Spacer(Modifier.height(24.dp))

        Text(
            "Aktivitas Terbaru",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(Modifier.height(10.dp))

        ActivityItem(Icons.Default.CheckCircle, CashyColors.Success, "Transaksi berhasil", "Order selesai")
        ActivityItem(Icons.Default.Warning, CashyColors.Warning, "Stok menipis", "Indomie tinggal 4")
        ActivityItem(Icons.Default.Refresh, CashyColors.Accent, "Update produk", "Harga berubah")
    }
}

/* ================= STAT CARD ================= */

@Composable
private fun StatCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    sub: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CashyColors.Surface)
    ) {
        Column(Modifier.padding(16.dp)) {

            Text(title, fontSize = 12.sp, color = CashyColors.TextSecondary)

            Spacer(Modifier.height(4.dp))

            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)

            Spacer(Modifier.height(10.dp))

            Text(sub, fontSize = 11.sp, color = CashyColors.Primary)
        }
    }
}

/* ================= ACTIVITY ITEM ================= */

@Composable
private fun ActivityItem(
    icon: ImageVector,
    color: Color,
    title: String,
    subtitle: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(CashyColors.Surface)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.15f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = color)
        }

        Spacer(Modifier.width(12.dp))

        Column {
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(subtitle, fontSize = 11.sp, color = CashyColors.TextSecondary)
        }
    }
}
@Composable
fun TransactionSummaryCard(
    cashState: CashState,
    totalSaldo: Double,
    onAddTransaction: () -> Unit,
    onOpenHistory: () -> Unit
) {

    Box(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxWidth()
            .background(
                color = Color(0xFF002F3B),
                shape = RoundedCornerShape(20.dp)
            )
            .padding(19.dp)
    ) {

        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {

            /* ================= TOP ROW ================= */
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {

                Text(
                    text = "Cash Balance",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Normal
                )

                Row(verticalAlignment = Alignment.CenterVertically) {

                    // Today tadinye

                    Spacer(Modifier.width(6.dp))

                    // dropdown icon placeholder

                }
            }

            /* ================= TOTAL VALUE ================= */
            Text(
                text = when (cashState) {
                    is CashState.Loading -> "Loading..."
                    else -> formatRupiah(totalSaldo)
                },
                color = Color.White,
                fontSize = 29.sp,
                fontWeight = FontWeight.SemiBold
            )

            /* ================= BUTTON ROW ================= */
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {

                // ADD TRANSACTION
                Row(
                    modifier = Modifier
                        .height(43.dp)
                        .width(192.dp)
                        .clip(RoundedCornerShape(30.dp))
                        .background(Color(0xFFF0F0F0))
                        .clickable { onAddTransaction() }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = Color.Black
                    )

                    Spacer(Modifier.width(8.dp))

                    Text(
                        text = "Add Transaction",
                        fontSize = 14.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Medium
                    )
                }

                // HISTORY
                Row(
                    modifier = Modifier
                        .height(43.dp)
                        .width(125.dp)
                        .clip(RoundedCornerShape(30.dp))
                        .background(Color(0xFFF0F0F0))
                        .clickable { onOpenHistory() }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = Color.Black
                    )

                    Spacer(Modifier.width(8.dp))

                    Text(
                        text = "History",
                        fontSize = 14.sp,
                        color = Color.Black,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
    }
}