package com.example.supabaseauth.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.supabaseauth.data.SupabaseClientProvider
import com.example.supabaseauth.model.Pelanggan
import com.example.supabaseauth.model.Penjualan
import com.example.supabaseauth.model.PenjualanUI
import com.example.supabaseauth.repository.ExpenseRepository
import io.github.jan.supabase.postgrest.from
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class TransactionViewModel : ViewModel() {

    private val client = SupabaseClientProvider.client

    private val _transactions =
        MutableStateFlow<List<PenjualanUI>>(emptyList())

    val transactions: StateFlow<List<PenjualanUI>> = _transactions

    fun loadAllTransactions() {

        viewModelScope.launch {

            try {

                val penjualan = client
                    .from("penjualan")
                    .select()
                    .decodeList<Penjualan>()

                val pelanggan = client
                    .from("pelanggan")
                    .select()
                    .decodeList<Pelanggan>()

                val result = penjualan.map { trx ->

                    val nama = pelanggan
                        .find { it.id == trx.pelanggan_id }
                        ?.nama ?: "Guest"

                    PenjualanUI(
                        id = trx.id ?: "",
                        pelangganNama = nama,
                        waktu = trx.waktu.toString(),
                        total = trx.total,
                        status = trx.status
                    )
                }

                _transactions.value = result

            } catch (e: Exception) {
                _transactions.value = emptyList()
            }
        }
    }
}