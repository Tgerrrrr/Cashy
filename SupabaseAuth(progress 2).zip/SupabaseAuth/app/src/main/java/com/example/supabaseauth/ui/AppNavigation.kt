package com.example.supabaseauth.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.supabaseauth.viewmodel.AuthCheckState
import com.example.supabaseauth.viewmodel.AuthViewModel

private val NavBg         = Color(0xFFFFFFFF)
private val NavPrimary    = Color(0xFF1A3C40)
private val NavUnselected = Color(0xFF90A4AE)
private val NavIndicator  = Color(0xFFE0F2F1)
private val ScaffoldBg    = Color(0xFFF4F6F8)

private val bottomNavRoutes = setOf(
    Screen.Home.route,
    Screen.Transaction.route,
    Screen.Product.route,
    Screen.History.route,
    Screen.Profile.route
)

@Composable
fun AppNavigation(
    navController: NavHostController,
    authViewModel: AuthViewModel
) {
    val authCheckState by authViewModel.authCheckState.collectAsStateWithLifecycle()
    val authUiState    by authViewModel.authUiState.collectAsStateWithLifecycle()
    val currentEmail   by authViewModel.currentUserEmail.collectAsStateWithLifecycle()

    // Show spinner while checking session — never mount NavHost with unstable state
    if (authCheckState == AuthCheckState.Checking) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = Color(0xFF00657E))
        }
        return
    }

    val startDestination = when (authCheckState) {
        AuthCheckState.LoggedIn -> Screen.Home.route
        else                    -> Screen.Login.route
    }

    val navBackStack by navController.currentBackStackEntryAsState()
    val currentRoute  = navBackStack?.destination?.route
    val showBottomNav = currentRoute in bottomNavRoutes

    // Only navigate when state actually changes after initial mount
    var previousState by remember { mutableStateOf(authCheckState) }
    LaunchedEffect(authCheckState) {
        if (authCheckState == previousState) return@LaunchedEffect
        previousState = authCheckState
        when (authCheckState) {
            AuthCheckState.LoggedIn -> {
                navController.navigate(Screen.Home.route) {
                    popUpTo(0) { inclusive = true }
                }
            }
            AuthCheckState.LoggedOut -> {
                val current = navController.currentBackStackEntry?.destination?.route
                if (current != Screen.Login.route) {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }
            }
            else -> Unit
        }
    }

    Scaffold(
        containerColor = ScaffoldBg,
        bottomBar = {
            if (showBottomNav) {
                CashyBottomNav(
                    currentRoute = currentRoute,
                    onNavigate = { route ->
                        if (currentRoute != route) {
                            navController.navigate(route) {
                                popUpTo(Screen.Home.route) { saveState = true }
                                launchSingleTop = true
                                restoreState    = true
                            }
                        }
                    }
                )
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = startDestination,
            modifier         = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Login.route) {
                LoginScreen(
                    authViewModel = authViewModel,
                    onSignup = { navController.navigate(Screen.Register.route) }
                )
            }
            composable(Screen.Register.route) {
                RegisterScreen(
                    authViewModel     = authViewModel,
                    authUiState       = authUiState,
                    onNavigateToLogin = { navController.popBackStack() }
                )
            }
            composable(Screen.Home.route) {
                HomeScreen(
                    authViewModel = authViewModel,
                    navController = navController,
                    onLogout      = { authViewModel.logout() }
                )
            }
            composable(Screen.Transaction.route) { TransactionScreen() }
            composable(Screen.Product.route) {
                ProductScreen(navController = navController)
            }
            composable(Screen.History.route) { HistoryScreen() }
            composable(Screen.Profile.route) {
                ProfileScreen(
                    currentUserEmail = currentEmail,
                    onLogout         = { authViewModel.logout() }
                )
            }
            composable(Screen.Customer.route) { CustomerScreen() }
            composable(Screen.Cash.route)     { CashScreen() }
            composable(Screen.Expense.route)  { ExpenseScreen() }
            composable(Screen.Sales.route)    { SalesScreen() }
            composable("manage_product/{productId}") { backStackEntry ->
                val productId = backStackEntry.arguments?.getString("productId")
                ManageProductScreen(
                    navController = navController,
                    productId     = if (productId == "new") null else productId
                )
            }
        }
    }
}

@Composable
fun CashyBottomNav(
    currentRoute: String?,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        BottomNavItem.Home,
        BottomNavItem.Transaction,
        BottomNavItem.Product,
        BottomNavItem.History,
        BottomNavItem.Profile
    )
    NavigationBar(
        containerColor = NavBg,
        tonalElevation = 0.dp
    ) {
        items.forEach { item ->
            val selected = currentRoute == item.route
            NavigationBarItem(
                selected = selected,
                onClick  = { onNavigate(item.route) },
                icon     = { Icon(item.icon, contentDescription = item.label) },
                label    = { Text(item.label, fontSize = 10.sp) },
                colors   = NavigationBarItemDefaults.colors(
                    selectedIconColor   = NavPrimary,
                    selectedTextColor   = NavPrimary,
                    unselectedIconColor = NavUnselected,
                    unselectedTextColor = NavUnselected,
                    indicatorColor      = NavIndicator
                )
            )
        }
    }
}