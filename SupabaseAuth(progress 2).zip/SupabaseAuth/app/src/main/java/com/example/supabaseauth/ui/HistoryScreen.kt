package com.example.supabaseauth.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ─────────────────────────────────────────────
   Data model for a single activity entry
───────────────────────────────────────────── */
data class ActivityEntry(
    val title: String,
    val details: List<String>,        // sub-lines shown below the title
    val timestamp: String,            // e.g. "11/10/26\n06:28"
    val category: String              // "Inventory" | "System" | …
)

/* ─────────────────────────────────────────────
   Sample / preview data  (replace with VM)
───────────────────────────────────────────── */
private val sampleActivities = listOf(
    ActivityEntry(
        title     = "STOCK ADDED (+120)",
        details   = listOf(
            "Admin: Raisa Shahla",
            "Product: Product #78fd2",
            "\"Espresso Arabica\"",
            "Stock: 0 → 120",
            "Reference: Manual Input"
        ),
        timestamp = "11/10/26\n06:28",
        category  = "Inventory"
    ),
    ActivityEntry(
        title     = "Log in Detected",
        details   = listOf(
            "Cashier: Cashier 1",
            "192.632.727.11",
            "Loc: Lowokwaru, Malang"
        ),
        timestamp = "9/10/26\n09:30",
        category  = "System"
    ),
    ActivityEntry(
        title     = "STOCK REMOVED (-30)",
        details   = listOf(
            "Admin: Budi Santoso",
            "Product: Product #12abc",
            "\"Latte Oat\"",
            "Stock: 50 → 20",
            "Reference: Order #9921"
        ),
        timestamp = "8/10/26\n14:05",
        category  = "Inventory"
    ),
    ActivityEntry(
        title     = "Log out Detected",
        details   = listOf(
            "Cashier: Cashier 2",
            "10.0.0.5",
            "Loc: Klojen, Malang"
        ),
        timestamp = "8/10/26\n16:45",
        category  = "System"
    )
)

private val filterOptions = listOf("All", "Inventory", "System")

/* ─────────────────────────────────────────────
   Screen
───────────────────────────────────────────── */
@Composable
fun HistoryScreen() {

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("All") }

    val filtered = remember(searchQuery, selectedFilter) {
        sampleActivities.filter { entry ->
            val matchesFilter = selectedFilter == "All" || entry.category == selectedFilter
            val matchesSearch = searchQuery.isBlank() ||
                    entry.title.contains(searchQuery, ignoreCase = true) ||
                    entry.details.any { it.contains(searchQuery, ignoreCase = true) }
            matchesFilter && matchesSearch
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CashyColors.Background)
    ) {

        Spacer(Modifier.height(20.dp))

        /* ── Title ── */
        Text(
            text       = "Activity History",
            fontSize   = 20.sp,
            fontWeight = FontWeight.SemiBold,
            color      = Color.Black,
            modifier   = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            textAlign  = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(Modifier.height(16.dp))

        /* ── Search bar ── */
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(30.dp))
                .background(Color(0xFFF2F3F2))
                .padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector        = Icons.Default.Search,
                contentDescription = null,
                tint               = Color(0xFF7C7C7C)
            )
            Spacer(Modifier.width(10.dp))
            androidx.compose.foundation.text.BasicTextField(
                value         = searchQuery,
                onValueChange = { searchQuery = it },
                singleLine    = true,
                decorationBox = { inner ->
                    if (searchQuery.isEmpty()) {
                        Text("Search Activity", color = Color(0xFF7C7C7C), fontSize = 14.sp)
                    }
                    inner()
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        Spacer(Modifier.height(14.dp))

        /* ── Filter chips ── */
        LazyRow(
            contentPadding      = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filterOptions) { option ->
                ActivityFilterChip(
                    text     = option,
                    selected = selectedFilter == option,
                    onClick  = { selectedFilter = option }
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        /* ── Activity list ── */
        if (filtered.isEmpty()) {
            Box(
                modifier        = Modifier.fillMaxWidth().padding(top = 40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No activity found", color = Color.Gray)
            }
        } else {
            LazyColumn(
                contentPadding        = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
                verticalArrangement   = Arrangement.spacedBy(16.dp)
            ) {
                items(filtered) { entry ->
                    ActivityCard(entry = entry)
                }
            }
        }
    }
}

/* ─────────────────────────────────────────────
   Activity card
───────────────────────────────────────────── */
@Composable
private fun ActivityCard(entry: ActivityEntry) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 2.dp, shape = RoundedCornerShape(20.dp), ambientColor = Color.Black.copy(alpha = 0.03f))
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalAlignment = Alignment.Top
    ) {

        /* Icon circle */
        Box(
            modifier        = Modifier
                .size(29.dp)
                .clip(CircleShape)
                .background(Color(0xFFE6F3F6)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector        = Icons.Default.Info,
                contentDescription = null,
                tint               = Color(0xFF006C86),
                modifier           = Modifier.size(18.dp)
            )
        }

        Spacer(Modifier.width(14.dp))

        /* Detail column */
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = entry.title,
                fontSize   = 14.sp,
                fontWeight = FontWeight.Medium,
                color      = Color.Black,
                lineHeight = 16.8.sp
            )
            Spacer(Modifier.height(10.dp))
            entry.details.forEach { line ->
                Text(
                    text       = line,
                    fontSize   = 14.sp,
                    color      = Color(0xFF999999),
                    lineHeight = 16.8.sp
                )
            }
        }

        Spacer(Modifier.width(8.dp))

        /* Timestamp */
        Text(
            text      = entry.timestamp,
            fontSize  = 14.sp,
            color     = Color.Black,
            lineHeight = 16.8.sp,
            textAlign = androidx.compose.ui.text.style.TextAlign.End
        )
    }
}

/* ─────────────────────────────────────────────
   Filter chip
───────────────────────────────────────────── */
@Composable
private fun ActivityFilterChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(30.dp))
            .background(if (selected) Color(0xFF00657E) else Color(0xFFE6F3F6))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text      = text,
            fontSize  = 14.sp,
            fontWeight = FontWeight.Medium,
            color     = if (selected) Color.White else Color(0xFF003D4C)
        )
    }
}