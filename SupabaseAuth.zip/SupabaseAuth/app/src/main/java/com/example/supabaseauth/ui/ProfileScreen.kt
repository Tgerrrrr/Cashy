package com.example.supabaseauth.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ProfileScreen(
    currentUserEmail: String?,
    onLogout: () -> Unit
) {

    Column {

        Text(
            text = currentUserEmail
                ?: "No Email"
        )

        Button(
            onClick = onLogout
        ) {

            Text("Logout")
        }
    }
}