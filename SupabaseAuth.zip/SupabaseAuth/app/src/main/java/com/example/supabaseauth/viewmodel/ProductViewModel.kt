package com.example.supabaseauth.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.supabaseauth.model.Produk
import com.example.supabaseauth.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class ProductViewModel : ViewModel() {

    private val repository =
        ProductRepository()

    private val _productList =
        MutableStateFlow<List<Produk>>(
            emptyList()
        )

    val productList:
            StateFlow<List<Produk>> =
        _productList

    init {

        loadProducts()
    }

    fun loadProducts() {

        viewModelScope.launch {

            _productList.value =
                repository.getProducts()
        }
    }

    fun addDummyProduct() {

        viewModelScope.launch {

            repository.addProduct(

                Produk(
                    nama = "Produk Baru",
                    harga = 10000.0,
                    stok = 5.0
                )
            )

            loadProducts()
        }
    }

    fun deleteProduct(
        id: String
    ) {

        viewModelScope.launch {

            repository.deleteProduct(id)

            loadProducts()
        }
    }
}