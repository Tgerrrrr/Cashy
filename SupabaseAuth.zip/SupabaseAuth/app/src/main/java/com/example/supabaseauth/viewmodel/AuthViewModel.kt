package com.example.supabaseauth.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel : ViewModel() {

    // ─────────────────────────────────────────────
    // UI STATE
    // ─────────────────────────────────────────────
    private val _authUiState =
        MutableStateFlow<AuthUiState>(
            AuthUiState.Idle
        )

    val authUiState: StateFlow<AuthUiState> =
        _authUiState.asStateFlow()

    // ─────────────────────────────────────────────
    // AUTH CHECK STATE
    // ─────────────────────────────────────────────
    private val _authCheckState =
        MutableStateFlow<AuthCheckState>(
            AuthCheckState.Checking
        )

    val authCheckState:
            StateFlow<AuthCheckState> =
        _authCheckState.asStateFlow()

    // ─────────────────────────────────────────────
    // CURRENT USER EMAIL
    // ─────────────────────────────────────────────
    private val _currentUserEmail =
        MutableStateFlow<String?>(null)

    val currentUserEmail:
            StateFlow<String?> =
        _currentUserEmail.asStateFlow()

    // ─────────────────────────────────────────────
    // CURRENT USER ROLE
    // ─────────────────────────────────────────────
    private val _currentUserRole =
        MutableStateFlow("cashier")

    val currentUserRole:
            StateFlow<String> =
        _currentUserRole.asStateFlow()

    // ─────────────────────────────────────────────
    // INIT
    // ─────────────────────────────────────────────
    init {

        checkSession()
    }

    // ─────────────────────────────────────────────
    // CHECK SESSION
    // ─────────────────────────────────────────────
    fun checkSession() {

        viewModelScope.launch {

            _authCheckState.value =
                AuthCheckState.Checking

            try {

                // TODO:
                // CHECK SUPABASE SESSION HERE

                val sessionExists = false

                if (sessionExists) {

                    _authCheckState.value =
                        AuthCheckState.LoggedIn

                    _currentUserEmail.value =
                        "admin@example.com"

                    _currentUserRole.value =
                        "admin"

                } else {

                    _authCheckState.value =
                        AuthCheckState.LoggedOut

                    _currentUserEmail.value =
                        null

                    _currentUserRole.value =
                        "cashier"
                }

            } catch (e: Exception) {

                _authCheckState.value =
                    AuthCheckState.LoggedOut

                _currentUserEmail.value =
                    null

                _currentUserRole.value =
                    "cashier"
            }
        }
    }

    // ─────────────────────────────────────────────
    // LOGIN
    // ─────────────────────────────────────────────
    fun login(
        email: String,
        password: String
    ) {

        viewModelScope.launch {

            _authUiState.value =
                AuthUiState.Loading

            try {

                // TODO:
                // SUPABASE LOGIN

                _currentUserEmail.value =
                    email

                // =================================
                // SIMPLE ROLE CHECK
                // =================================
                _currentUserRole.value =

                    if (
                        email.contains("admin")
                    ) {
                        "admin"
                    } else {
                        "cashier"
                    }

                _authUiState.value =
                    AuthUiState.Success()

                _authCheckState.value =
                    AuthCheckState.LoggedIn

            } catch (e: Exception) {

                _authUiState.value =
                    AuthUiState.Error(
                        e.message
                            ?: "Login gagal"
                    )
            }
        }
    }

    // ─────────────────────────────────────────────
    // REGISTER
    // ─────────────────────────────────────────────
    fun register(
        email: String,
        password: String,
        fullName: String
    ) {

        viewModelScope.launch {

            _authUiState.value =
                AuthUiState.Loading

            try {

                // TODO:
                // SUPABASE REGISTER

                _currentUserEmail.value =
                    email

                _currentUserRole.value =
                    "cashier"

                _authUiState.value =
                    AuthUiState.Success()

                _authCheckState.value =
                    AuthCheckState.LoggedIn

            } catch (e: Exception) {

                _authUiState.value =
                    AuthUiState.Error(
                        e.message
                            ?: "Register gagal"
                    )
            }
        }
    }

    // ─────────────────────────────────────────────
    // LOGOUT
    // ─────────────────────────────────────────────
    fun logout() {

        viewModelScope.launch {

            // TODO:
            // SUPABASE LOGOUT

            _currentUserEmail.value =
                null

            _currentUserRole.value =
                "cashier"

            _authUiState.value =
                AuthUiState.Idle

            _authCheckState.value =
                AuthCheckState.LoggedOut
        }
    }

    // ─────────────────────────────────────────────
    // RESET UI STATE
    // ─────────────────────────────────────────────
    fun resetUiState() {

        _authUiState.value =
            AuthUiState.Idle
    }
}