package com.example.supabaseauth.model

import kotlinx.serialization.Serializable

@Serializable
data class Product(

    val id: String? = null,

    val nama: String,

    val harga: Double,

    val stok: Int
)