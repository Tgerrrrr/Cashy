package com.example.supabaseauth.repository

import com.example.supabaseauth.data.SupabaseClientProvider
import com.example.supabaseauth.model.Produk
import io.github.jan.supabase.postgrest.from

class ProductRepository {

    private val client = SupabaseClientProvider.client

    suspend fun getProducts(): List<Produk> {
        return client
            .from("produk")
            .select()
            .decodeList()
    }

    suspend fun addProduct(product: Produk) {
        client.from("produk").insert(product)
    }

    suspend fun updateProduct(product: Produk) {
        client
            .from("produk")
            .update(product) {
                filter {
                    eq("id", product.id!!)
                }
            }
    }

    suspend fun deleteProduct(id: String) {
        client
            .from("produk")
            .delete {
                filter {
                    eq("id", id)
                }
            }
    }
}