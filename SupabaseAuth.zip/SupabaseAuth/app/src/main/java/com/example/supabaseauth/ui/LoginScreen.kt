package com.example.supabaseauth.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.supabaseauth.viewmodel.AuthUiState
import com.example.supabaseauth.viewmodel.AuthViewModel

@Composable
fun LoginScreen(
    authViewModel: AuthViewModel,
    authUiState: AuthUiState,
    onNavigateToRegister: () -> Unit
) {

    var email by remember {

        mutableStateOf("")
    }

    var password by remember {

        mutableStateOf("")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        OutlinedTextField(
            value = email,
            onValueChange = {

                email = it
            },
            label = {

                Text("Email")
            }
        )

        OutlinedTextField(
            value = password,
            onValueChange = {

                password = it
            },
            label = {

                Text("Password")
            }
        )

        Button(
            onClick = {

                authViewModel.login(
                    email,
                    password
                )
            }
        ) {

            Text("Login")
        }

        Button(
            onClick =
                onNavigateToRegister
        ) {

            Text("Register")
        }
    }
}