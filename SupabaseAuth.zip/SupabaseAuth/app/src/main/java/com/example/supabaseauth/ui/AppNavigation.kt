package com.example.supabaseauth.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.supabaseauth.viewmodel.AuthCheckState
import com.example.supabaseauth.viewmodel.AuthViewModel

@Composable
fun AppNavigation(
    navController: NavHostController,
    authViewModel: AuthViewModel
) {

    // =========================================
    // OBSERVE AUTH STATE
    // =========================================
    val authCheckState by authViewModel
        .authCheckState
        .collectAsState()

    val authUiState by authViewModel
        .authUiState
        .collectAsState()

    // =========================================
    // START DESTINATION
    // =========================================
    val startDestination = when (authCheckState) {

        AuthCheckState.Checking -> {
            Screen.Login.route
        }

        AuthCheckState.LoggedIn -> {
            Screen.Home.route
        }

        AuthCheckState.LoggedOut -> {
            Screen.Login.route
        }
    }

    // =========================================
    // NAVIGATION HOST
    // =========================================
    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {

        // =====================================
        // LOGIN
        // =====================================
        composable(Screen.Login.route) {

            LoginScreen(
                authViewModel = authViewModel,
                authUiState = authUiState,

                onNavigateToRegister = {

                    navController.navigate(
                        Screen.Register.route
                    )
                }
            )
        }

        // =====================================
        // REGISTER
        // =====================================
        composable(Screen.Register.route) {

            RegisterScreen(
                authViewModel = authViewModel,
                authUiState = authUiState,

                onNavigateToLogin = {

                    navController.popBackStack()
                }
            )
        }

        // =====================================
        // HOME
        // =====================================
        composable(Screen.Home.route) {

            HomeScreen(

                authViewModel = authViewModel,

                onLogout = {

                    authViewModel.logout()

                    navController.navigate(
                        Screen.Login.route
                    ) {

                        popUpTo(Screen.Home.route) {
                            inclusive = true
                        }
                    }
                }
            )
        }

        // =====================================
        // PRODUCT
        // =====================================
        composable(Screen.Product.route) {

            ProductScreen()
        }

        // =====================================
        // CUSTOMER
        // =====================================
        composable(Screen.Customer.route) {

            CustomerScreen()
        }

        // =====================================
        // CASH
        // =====================================
        composable(Screen.Cash.route) {

            CashScreen()
        }

        // =====================================
        // EXPENSE
        // =====================================
        composable(Screen.Expense.route) {

            ExpenseScreen()
        }

        // =====================================
        // SALES
        // =====================================
        composable(Screen.Sales.route) {

            SalesScreen()
        }
    }
}