package com.example.supabaseauth.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Profile(
    val id: String,
    val full_name: String? = null,
    val role: String = "cashier"
)

@Serializable
data class Kas(
    val id: String? = null,
    val nama: String,
    val saldo: Double,
    val is_active: Boolean = true,
    val created_at: String? = null
)

@Serializable
data class Pelanggan(
    val id: String? = null,
    val nama: String,
    val no_telp: String? = null,
    val is_active: Boolean = true,
    val created_at: String? = null
)

@Serializable
data class Produk(
    val id: String? = null,
    val nama: String,
    val harga: Double,
    val stok: Double,
    val is_active: Boolean = true,
    val created_at: String? = null,
    val updated_at: String? = null
)

@Serializable
data class Pengeluaran(
    val id: String? = null,
    val kas_id: String,
    val tanggal: String,
    val deskripsi: String,
    val total: Double,
    val is_cancelled: Boolean = false
)

@Serializable

data class Penjualan(
    val id: String? = null,
    val pelanggan_id: String? = null,
    val kas_id: String,
    val waktu: String,
    val total: Double,
    val jumlah_bayar: Double,
    val status: String
)

@Serializable

data class PenjualanItem(
    val id: String? = null,
    val penjualan_id: String,
    val produk_id: String,
    val nama_produk: String,
    val harga_satuan: Double,
    val qty: Double,
    val subtotal: Double
)