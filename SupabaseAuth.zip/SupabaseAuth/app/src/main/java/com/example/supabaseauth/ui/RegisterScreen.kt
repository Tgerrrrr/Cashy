package com.example.supabaseauth.ui

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import com.example.supabaseauth.viewmodel.*

@Composable
fun RegisterScreen(
    authViewModel: AuthViewModel,
    authUiState: AuthUiState,
    onNavigateToLogin: () -> Unit
) {

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }

    val isValid =
        fullName.isNotBlank() &&
                email.contains("@") &&
                password.length >= 8 &&
                password == confirm

    Column(modifier = Modifier.padding(24.dp)) {

        Text("Register", style = MaterialTheme.typography.headlineMedium)

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(fullName, { fullName = it }, label = { Text("Name") })
        OutlinedTextField(email, { email = it }, label = { Text("Email") })
        OutlinedTextField(password, { password = it }, label = { Text("Password") })
        OutlinedTextField(confirm, { confirm = it }, label = { Text("Confirm") })

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                authViewModel.register(email, password, fullName)
            },
            enabled = isValid && authUiState !is AuthUiState.Loading,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (authUiState is AuthUiState.Loading) {
                CircularProgressIndicator()
            } else {
                Text("Register")
            }
        }

        TextButton(onClick = onNavigateToLogin) {
            Text("Back to Login")
        }

        if (authUiState is AuthUiState.Error) {
            Text(authUiState.message, color = MaterialTheme.colorScheme.error)
        }
    }
}