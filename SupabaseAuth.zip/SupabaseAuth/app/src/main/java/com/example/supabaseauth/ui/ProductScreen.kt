package com.example.supabaseauth.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.supabaseauth.model.Produk
import com.example.supabaseauth.viewmodel.ProductViewModel

@Composable
fun ProductScreen(
    productViewModel: ProductViewModel = viewModel()
) {

    val products by productViewModel
        .productList
        .collectAsState()

    LaunchedEffect(Unit) {

        productViewModel.loadProducts()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {

        Button(
            onClick = {

                productViewModel.addDummyProduct()
            }
        ) {

            Text("Tambah Product")
        }

        LazyColumn(
            verticalArrangement =
                Arrangement.spacedBy(8.dp)
        ) {

            items(products) { product: Produk ->

                Card {

                    Column(
                        modifier =
                            Modifier.padding(16.dp)
                    ) {

                        Text(product.nama)

                        Text(
                            "Harga: ${product.harga}"
                        )

                        Text(
                            "Stok: ${product.stok}"
                        )

                        Button(
                            onClick = {

                                product.id?.let {

                                    productViewModel
                                        .deleteProduct(it)
                                }
                            }
                        ) {

                            Text("Hapus")
                        }
                    }
                }
            }
        }
    }
}